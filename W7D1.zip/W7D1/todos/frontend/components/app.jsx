import React from 'react';

const App = () => <h1>Todos App</h1>;

export default App;
